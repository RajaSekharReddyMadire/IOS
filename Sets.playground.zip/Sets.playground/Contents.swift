import UIKit

var greeting = "Hello, playground"

var players : Set<String> = ["Virat Kohli","David Warner","M.S.Dhoni","Yuvaraj"]
print(players.count)

print(players)

print(players.contains("Virat Kohli"))
players.insert("ViratKohli")
print(players)
players.insert("Maxi")
print(players)
print(players.contains("Virat Kohli"))
print(players.remove("David Warner")!)
print(players)



var primaryNumbers : Set<Int> = [2,3,5,7,11]
var numbers : Set<Int> = [1,2,3,4,5]

var unionSet = numbers.union(primaryNumbers)
print(unionSet)

var intersectionSet = numbers.intersection(primaryNumbers)
print(intersectionSet)

var substractionSet = primaryNumbers.subtracting(numbers)

var subtractSet = numbers.subtracting(primaryNumbers)

var symmetricSet = primaryNumbers.symmetricDifference(numbers)

var symmetricSet1 = numbers.symmetricDifference(primaryNumbers)
print(symmetricSet1)
print(symmetricSet)
print(substractionSet)
print(subtractSet)
