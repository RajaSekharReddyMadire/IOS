import UIKit

var greeting = "Hello, playground"

var capitals = ["Arkansas":"LittleRock","Georgia":"Atlanta"]
print(capitals)
print(capitals.count)
var numbers = [1:"one",2:"two",3:"three"]
print(numbers)
numbers[4] = "four"
print(numbers)
var courses = [44542:"Java",44560:"Database",44613:"Data Visualization"]
print(courses)

print("Before changing \(courses)")
courses[44542] = "Java Script"
print("After changing \(courses)")

print(courses[44542]!)

courses.removeValue(forKey: 44542)
print(courses)

for(key,value) in courses{
    print(key)
}

for(key,value) in courses{
    print(value)
}

for(key,value) in courses{
    print("\(key) : \(value)")
}

